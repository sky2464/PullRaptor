"""PullRaptor review kernel package."""

__version__ = "0.1.0b2.dev0"
