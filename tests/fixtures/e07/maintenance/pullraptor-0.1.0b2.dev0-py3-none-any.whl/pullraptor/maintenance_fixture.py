"""Unpublished BR18 source identity fixture; no runtime behavior change."""
FIXTURE_ID = "BR18-0.1.0b2.dev0"
