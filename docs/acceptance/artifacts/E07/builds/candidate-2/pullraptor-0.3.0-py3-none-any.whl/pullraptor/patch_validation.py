"""Pure, revision-bound E06 validation. This module never runs target code.

Reports and execution records are observations. A coordinator supplies the
expected binding; an independently trusted boundary admits execution receipts.
The default has no execution authority and leaves P4 not_run.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Protocol
import time
from pullraptor.evidence import validate_receipts
from pullraptor.models import (FullReport, ReviewContract, RecordLimits, Deadline,
    canonical_bytes)
from pullraptor.patches import PatchedTree, StageResult

@dataclass(frozen=True)
class ObligationPredicate:
    obligation_id: str
    rule: str
    version: str
    predicate: str

@dataclass(frozen=True)
class ValidationBinding:
    original_contract: ReviewContract
    patched_contract: ReviewContract
    current_head: str
    obligations: tuple[ObligationPredicate, ...]

@dataclass(frozen=True)
class CheckReceipt:
    argv: tuple[str, ...]
    obligation_id: str
    predicate: str
    baseline_status: str
    patched_status: str
    termination: str

@dataclass(frozen=True)
class ExecutionEvidence:
    original_tree: str
    result_tree: str
    patch_digest: str
    policy_digest: str
    config_digest: str
    tool_digest: str
    image_digest: str
    runtime: str
    checks: tuple[CheckReceipt, ...]

class ExecutionAuthority(Protocol):
    """Trusted adapter verifies actual baseline/patched receipts and relevance.

    Must authenticate provenance, scope, same argv/runtime/image/inputs/limits,
    enforced isolation and actual statuses; caller supplied labels cannot admit.
    No production implementation of this boundary is provided here.
    """
    def admit(self, evidence: ExecutionEvidence, binding: ValidationBinding,
              patch: PatchedTree) -> bool: ...

@dataclass(frozen=True)
class ObligationResult:
    obligation_id: str
    rule: str
    version: str
    predicate: str
    outcome: str

@dataclass(frozen=True)
class ValidationReceipt:
    patch_digest: str
    original_tree: str
    result_tree: str
    stages: tuple[StageResult, ...]
    obligation_results: tuple[ObligationResult, ...]
    execution: ExecutionEvidence | None
    execution_status: str

    def stage(self, name: str) -> StageResult:
        return next(stage for stage in self.stages if stage.stage == name)


def _complete(report: FullReport) -> bool:
    expected = report.contract.expected_scope
    return (report.contract.discovery_complete and bool(expected)
        and len({entry.key for entry in expected}) == len(expected)
        and not validate_receipts(report.contract, report.receipts)
        and all(receipt.status == 'complete' for receipt in report.receipts))


def _same_policy(binding: ValidationBinding) -> bool:
    a, b = binding.original_contract, binding.patched_contract
    return all(getattr(a, field) == getattr(b, field) for field in (
        'base_tip', 'comparison_base', 'policy_digest', 'config_digest', 'tool_digest', 'profile'))


def _parse_stage(report: FullReport) -> StageResult:
    # Initial admitted static input is Python structure. Other grammar support
    # requires its own explicit parsing observation contract.
    expected = {entry.key for entry in report.contract.expected_scope
                if entry.capability == 'python_structure'}
    if not expected or validate_receipts(report.contract, report.receipts):
        return StageResult('P2', 'not_run', 'parse_coverage_unavailable')
    receipts = tuple(r for r in report.receipts if r.key in expected)
    if any(r.status == 'failed' or r.cause == 'parse_failed' for r in receipts):
        return StageResult('P2', 'failed', 'parse_failed')
    if any(r.status != 'complete' for r in receipts):
        return StageResult('P2', 'not_run', 'parse_incomplete')
    return StageResult('P2', 'passed', 'python_structure_receipts')


def validate_correction(original: FullReport, patched: FullReport,
        patch: PatchedTree, execution: ExecutionEvidence | None = None, *,
        binding: ValidationBinding | None = None,
        execution_authority: ExecutionAuthority | None = None,
        incremental: FullReport | None = None,
        limits: RecordLimits | None = None, deadline: Deadline | None = None) -> ValidationReceipt:
    """Retain five dependent stages, checked predicates and honest missing states.

    Empty findings never prove a correction. Static refutations remain static;
    reproduction requires an admitted relevant baseline failure and patched pass.
    Clean/incremental comparison excludes only nonsemantic execution metadata.
    """
    stages = {name: StageResult(name, 'not_run', 'prerequisite_unavailable')
              for name in ('P0', 'P1', 'P2', 'P3', 'P4')}
    obligations = binding.obligations if binding else ()
    outcomes = {item.obligation_id: 'open' for item in obligations}
    execution_status = 'not_run'

    def result() -> ValidationReceipt:
        return ValidationReceipt(patch.patch_digest, patch.original_tree, patch.result_tree,
            tuple(stages.values()), tuple(ObligationResult(item.obligation_id,
            item.rule, item.version, item.predicate, outcomes[item.obligation_id])
            for item in obligations), execution, execution_status)

    if binding is None:
        stages['P0'] = StageResult('P0', 'not_run', 'trusted_binding_required')
        return result()
    if len({item.obligation_id for item in obligations}) != len(obligations):
        stages['P0'] = StageResult('P0', 'failed', 'duplicate_obligation')
        return result()
    if (binding.current_head != patch.original_tree
            or binding.original_contract.head != patch.original_tree
            or binding.patched_contract.head != patch.result_tree):
        stages['P0'] = StageResult('P0', 'stale', 'head_or_tree_mismatch')
        return result()
    upstream = {s.stage: s for s in patch.stages}
    if len(upstream) != len(patch.stages) or set(upstream) != {'P0', 'P1'}:
        stages['P0'] = StageResult('P0', 'failed', 'invalid_patch_stages')
        return result()
    for name in ('P0', 'P1'):
        stage = upstream[name]
        if stage.status not in ('passed', 'failed', 'not_run', 'stale'):
            stages[name] = StageResult(name, 'failed', 'invalid_stage_status')
            return result()
        stages[name] = stage
        if stage.status != 'passed':
            return result()
    if (not isinstance(original, FullReport) or not isinstance(patched, FullReport)
            or original.contract != binding.original_contract
            or patched.contract != binding.patched_contract or not _same_policy(binding)):
        stages['P3'] = StageResult('P3', 'stale', 'analysis_binding_mismatch')
        return result()
    stages['P2'] = _parse_stage(patched)
    if stages['P2'].status != 'passed':
        return result()
    if not _complete(original) or not _complete(patched):
        stages['P3'] = StageResult('P3', 'not_run', 'analysis_incomplete')
        return result()
    if incremental is not None:
        limits = limits or RecordLimits()
        deadline = deadline or Deadline(time.monotonic(), 60.0)
        if incremental.contract != binding.patched_contract or not _complete(incremental):
            stages['P3'] = StageResult('P3', 'failed', 'incremental_binding_or_coverage')
            return result()
        try:
            equal = canonical_bytes(patched, limits=limits, deadline=deadline) == canonical_bytes(
                incremental, limits=limits, deadline=deadline)
        except (ValueError, TimeoutError):
            stages['P3'] = StageResult('P3', 'not_run', 'comparison_limit')
            return result()
        if not equal:
            stages['P3'] = StageResult('P3', 'failed', 'clean_incremental_mismatch')
            return result()
    stages['P3'] = StageResult('P3', 'passed', 'bound_static_reanalysis')
    # An explicitly refuted matching rule observation is scoped static evidence,
    # never a generic fixed/verified label or authorization to merge.
    for item in obligations:
        matches = tuple(f for f in patched.findings if (f.obligation, f.rule, f.version)
                        == (item.obligation_id, item.rule, item.version))
        if matches and all(f.state == 'refuted' for f in matches):
            outcomes[item.obligation_id] = 'statically_refuted'
    if execution is None or execution_authority is None:
        stages['P4'] = StageResult('P4', 'not_run', 'execution_authority_unavailable')
        return result()
    if not isinstance(execution, ExecutionEvidence):
        stages['P4'] = StageResult('P4', 'not_run', 'unsupported_execution_receipt')
        return result()
    fields = ((execution.original_tree, patch.original_tree),
        (execution.result_tree, patch.result_tree), (execution.patch_digest, patch.patch_digest),
        (execution.policy_digest, binding.patched_contract.policy_digest),
        (execution.config_digest, binding.patched_contract.config_digest),
        (execution.tool_digest, binding.patched_contract.tool_digest))
    if any(a != b for a, b in fields):
        stages['P4'] = StageResult('P4', 'stale', 'execution_binding_mismatch')
        return result()
    if (not execution.image_digest or not execution.runtime or not execution.checks
            or not execution_authority.admit(execution, binding, patch)):
        stages['P4'] = StageResult('P4', 'not_run', 'execution_not_admitted')
        return result()
    if any(not check.argv or check.termination != 'completed'
           or check.patched_status != 'passed' for check in execution.checks):
        stages['P4'] = StageResult('P4', 'failed', 'check_failed_or_incomplete')
        execution_status = 'checks_failed'
        return result()
    stages['P4'] = StageResult('P4', 'passed', 'admitted_configured_checks')
    execution_status = 'checks_passed'
    for item in obligations:
        relevant = tuple(check for check in execution.checks
                         if (check.obligation_id, check.predicate) == (item.obligation_id, item.predicate))
        retained = any(f.obligation == item.obligation_id and f.state != 'refuted'
                       for f in patched.findings)
        if relevant and not retained and all(check.baseline_status == 'failed' for check in relevant):
            outcomes[item.obligation_id] = 'regression_reproduced_and_resolved'
    if obligations and all(outcomes[item.obligation_id] == 'regression_reproduced_and_resolved'
                           for item in obligations):
        execution_status = 'regression_reproduced_and_resolved'
    return result()
