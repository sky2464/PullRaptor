"""Pure E06 runner plans and refusal records; this module never launches code."""
from dataclasses import dataclass
import re


@dataclass(frozen=True)
class RunnerPlan:
    image_digest: str
    argv: tuple[str, ...]
    input_tree: str
    max_cpu: int = 2
    max_memory_bytes: int = 2_147_483_648
    max_pids: int = 64
    max_seconds: int = 120
    max_stdout_bytes: int = 8_388_608
    max_stderr_bytes: int = 65_536
    network_policy: str = 'deny'
    profile: str = 'linux-x86_64-oci-proposed-v1'


@dataclass(frozen=True)
class IsolationControls:
    filesystem: bool = False
    egress: bool = False
    credentials: bool = False
    process_tree: bool = False
    cpu: bool = False
    memory: bool = False
    pids: bool = False
    output: bool = False
    deadline: bool = False


@dataclass(frozen=True)
class RunnerAdmission:
    allowed: bool
    cause: str
    missing_controls: tuple[str, ...] = ()


@dataclass(frozen=True)
class ExecutionReceipt:
    image_digest: str
    runtime: str
    input_tree: str
    argv: tuple[str, ...]
    status: str
    cause: str
    exit_code: int | None = None
    stdout_bytes: int = 0
    stderr_bytes: int = 0
    termination: str = 'not_started'
    profile: str = 'linux-x86_64-oci-proposed-v1'


def validate_runner(plan: RunnerPlan, controls: IsolationControls) -> RunnerAdmission:
    """Reject invalid plans and unsupported enforcement.

    Control flags are observations supplied by callers, never admission evidence.
    No execution backend is independently admitted in this construction revision.
    """
    if not isinstance(plan, RunnerPlan) or not isinstance(controls, IsolationControls):
        return RunnerAdmission(False, 'invalid_plan')
    if (not isinstance(plan.image_digest, str)
        or not re.fullmatch(r'sha256:[0-9a-f]{64}', plan.image_digest)
        or not isinstance(plan.input_tree, str)
        or not re.fullmatch(r'[0-9a-f]{40}|[0-9a-f]{64}', plan.input_tree)
        or plan.network_policy != 'deny'
        or plan.profile != 'linux-x86_64-oci-proposed-v1'
        or not isinstance(plan.argv, tuple) or not 1 <= len(plan.argv) <= 64
        or any(not isinstance(a, str) or not a or len(a.encode()) > 4096 or '\x00' in a for a in plan.argv)
        or not plan.argv[0].startswith('/')
        or plan.argv[0].rsplit('/', 1)[-1] in {'sh', 'bash', 'zsh', 'dash'}):
        return RunnerAdmission(False, 'invalid_plan')
    for field, cap in (('max_cpu', 2), ('max_memory_bytes', 2_147_483_648), ('max_pids', 64), ('max_seconds', 120), ('max_stdout_bytes', 8_388_608), ('max_stderr_bytes', 65_536)):
        value = getattr(plan, field)
        if type(value) is not int or not 0 < value <= cap:
            return RunnerAdmission(False, 'invalid_resource_limits')
    missing = tuple(name for name in controls.__dataclass_fields__ if getattr(controls, name) is not True)
    if missing:
        return RunnerAdmission(False, 'isolation_unavailable', missing)
    return RunnerAdmission(False, 'independent_admission_missing')
