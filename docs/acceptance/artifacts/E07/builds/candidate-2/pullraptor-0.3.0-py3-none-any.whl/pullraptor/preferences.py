"""Declarative local preferences; authentication belongs to a trusted adapter.

No production authentication is implemented here. The default authority denies.
Preferences produce a separate presentation overlay, never mutate CI Config.
"""
from __future__ import annotations
from dataclasses import dataclass
import hashlib
import json
from typing import Protocol

_SCHEMA = {
    'presentation_order': frozenset({'severity', 'path', 'rule'}),
    'advisory_display': frozenset({'expanded', 'compact'}),
}

@dataclass(frozen=True)
class PreferenceProposal:
    author: str
    source_report: str
    scope: str
    declarative_changes: tuple[tuple[str, str], ...]

@dataclass(frozen=True)
class ApprovalRequest:
    approver: str
    repository: str
    source_report: str
    policy_revision: str
    proposal_digest: str
    old_policy_digest: str

@dataclass(frozen=True)
class ApprovalGrant:
    request: ApprovalRequest
    authenticated_channel: str
    action_id: str

class ApprovalAuthority(Protocol):
    """Injected trusted channel must recheck current maintainer action/grants.

    A record decoded from source, feedback or model output is not this boundary.
    """
    def authorize(self, request: ApprovalRequest) -> ApprovalGrant | None: ...

@dataclass(frozen=True)
class AcceptedPreference:
    approver: str
    policy_revision: str
    proposal_digest: str
    source_report: str
    scope: str
    declarative_changes: tuple[tuple[str, str], ...]
    old_policy_digest: str
    new_policy_digest: str
    approval_channel: str
    approval_action: str

class PreferenceDenied(ValueError):
    pass

def _digest(value: object) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'),
        ensure_ascii=True, allow_nan=False).encode('utf-8')).hexdigest()

def _validate(proposal: PreferenceProposal) -> None:
    for value in (proposal.author, proposal.source_report, proposal.scope):
        if not isinstance(value, str) or not value or len(value) > 4096:
            raise PreferenceDenied('invalid_preference_identity')
    if not isinstance(proposal.declarative_changes, tuple) or not 1 <= len(proposal.declarative_changes) <= 2:
        raise PreferenceDenied('invalid_preference_changes')
    seen = set()
    for change in proposal.declarative_changes:
        if not isinstance(change, tuple) or len(change) != 2:
            raise PreferenceDenied('invalid_preference_changes')
        key, value = change
        if not isinstance(key, str) or key not in _SCHEMA:
            raise PreferenceDenied('protected_policy_key')
        if key in seen:
            raise PreferenceDenied('duplicate_preference_key')
        seen.add(key)
        if not isinstance(value, str) or value not in _SCHEMA[key]:
            raise PreferenceDenied('invalid_preference_value')

def proposal_digest(proposal: PreferenceProposal) -> str:
    _validate(proposal)
    return _digest((proposal.author, proposal.source_report, proposal.scope,
        sorted(proposal.declarative_changes)))

def accept_preference(proposal: PreferenceProposal, *, request: ApprovalRequest,
        allowed_keys: frozenset[str], authority: ApprovalAuthority | None = None) -> AcceptedPreference:
    """Admit only an exact independently authenticated local presentation action."""
    digest = proposal_digest(proposal)
    if any(key not in allowed_keys for key, _ in proposal.declarative_changes):
        raise PreferenceDenied('preference_key_not_allowed')
    if (request.repository != proposal.scope or request.source_report != proposal.source_report
            or request.proposal_digest != digest):
        raise PreferenceDenied('approval_binding_mismatch')
    if any(not isinstance(value, str) or not value or len(value) > 4096
           for value in (request.approver, request.policy_revision, request.old_policy_digest)):
        raise PreferenceDenied('invalid_approval_identity')
    if authority is None:
        raise PreferenceDenied('approval_required')
    grant = authority.authorize(request)
    if grant is None:
        raise PreferenceDenied('approval_required')
    if grant.request != request:
        raise PreferenceDenied('approval_binding_mismatch')
    if not grant.authenticated_channel or not grant.action_id:
        raise PreferenceDenied('approval_required')
    changes = tuple(sorted(proposal.declarative_changes))
    # Digest of the audited overlay, not a replacement trusted base CI policy.
    new_digest = _digest((request.old_policy_digest, digest, changes))
    return AcceptedPreference(request.approver, request.policy_revision, digest,
        proposal.source_report, proposal.scope, changes, request.old_policy_digest,
        new_digest, grant.authenticated_channel, grant.action_id)
