"""Immutable per-language capability evidence validation, without activation authority."""
from dataclasses import dataclass, replace
import re


@dataclass(frozen=True)
class CapabilityRow:
    language: str
    grammar_version: str
    capability: str
    state: str = 'proposed'
    evidence_path: str = ''


@dataclass(frozen=True)
class CapabilityMatrix:
    rows: tuple[CapabilityRow, ...]

    def __post_init__(self):
        keys = {(r.language, r.grammar_version, r.capability) for r in self.rows}
        if len(keys) != len(self.rows) or len(self.rows) > 256:
            raise ValueError('duplicate or excessive capability rows')

    def row(self, language: str, capability: str) -> CapabilityRow:
        matches = [r for r in self.rows if r.language == language and r.capability == capability]
        if len(matches) != 1:
            raise ValueError('missing or ambiguous capability')
        return matches[0]


@dataclass(frozen=True)
class CapabilityEvidence:
    language: str
    grammar_version: str
    capability: str
    dataset_revision: str
    positives: int
    negatives_unknown: int
    independent_labels: bool
    measurements: tuple[str, ...]
    evidence_path: str
    reviewer: str
    producer_digest: str
    runtime_digest: str
    license_reviewed: bool
    real_repository_evidence: bool


def admit_capability(matrix: CapabilityMatrix, evidence: CapabilityEvidence) -> CapabilityMatrix:
    """Validate a trusted caller's evidence summary; never activate a worker.

    Counts, flags and hashes cannot themselves establish correctness. An eligible
    row awaits independent artifact inspection and a separate acceptance action.
    """
    valid = (
        type(evidence.positives) is int and evidence.positives >= 30
        and type(evidence.negatives_unknown) is int and evidence.negatives_unknown >= 30
        and evidence.independent_labels is True and evidence.license_reviewed is True
        and evidence.real_repository_evidence is True and bool(evidence.reviewer)
        and bool(re.fullmatch(r'[0-9a-f]{40}|[0-9a-f]{64}', evidence.dataset_revision))
        and bool(re.fullmatch(r'[0-9a-f]{64}', evidence.producer_digest))
        and bool(re.fullmatch(r'[0-9a-f]{64}', evidence.runtime_digest))
        and {'startup','rss','size'} <= set(evidence.measurements)
        and evidence.evidence_path.startswith('docs/acceptance/')
        and '..' not in evidence.evidence_path.split('/')
    )
    if not valid:
        return matrix
    rows = tuple(replace(row, state='eligible_for_review', evidence_path=evidence.evidence_path) if (row.language, row.grammar_version, row.capability) == (evidence.language, evidence.grammar_version, evidence.capability) else row for row in matrix.rows)
    return CapabilityMatrix(rows)
