"""Bounded offline external observations; imported text is never review evidence."""
from dataclasses import dataclass
import math
import re
from pullraptor.models import RecordLimits, decode_record

@dataclass(frozen=True, order=True)
class ImportedSpan:
    path: str
    start_line: int
    start_column: int
    end_line: int
    end_column: int

@dataclass(frozen=True)
class ImportedObservation:
    producer: str
    version: str
    revision: str
    claim: str
    span: ImportedSpan | None
    trust: str
    rule: str = ''
    origin: str = ''
    language: str = 'unknown'
    scope: str = 'external claim; no corroboration or exploitability established'

def _object(value, required, optional=()):
    if not isinstance(value, dict) or set(value) - set(required) - set(optional) or set(required) - set(value):
        raise ValueError('Unsupported or missing record fields')
    return value

def _text(value):
    if not isinstance(value, str) or not value or any(ord(c) < 32 or ord(c) == 127 for c in value):
        raise ValueError('Nonempty inert text required')
    return value

def _revision(value):
    if not isinstance(value, str) or not re.fullmatch(r'(?:[0-9a-f]{40}|[0-9a-f]{64})', value):
        raise ValueError('Full lowercase object revision required')
    return value

def _list(value):
    if not isinstance(value, list):
        raise ValueError('Array required')
    return value

def _integer(value, minimum=0):
    if type(value) is not int or value < minimum:
        raise ValueError('Bounded integer required')
    return value

def _decode(payload, limits):
    record = decode_record(payload, 'external', limits)
    pending = [record]
    while pending:
        value = pending.pop()
        if isinstance(value, float) and not math.isfinite(value):
            raise ValueError('Nonfinite number rejected')
        if isinstance(value, dict): pending.extend(value.values())
        elif isinstance(value, list): pending.extend(value)
    return record

def _path(value):
    value = _text(value)
    if value.startswith('/') or any(c in value for c in ('\\', ':', '%', '?', '#')) or any(p in ('', '.', '..') for p in value.split('/')):
        raise ValueError('Canonical repository relative path required')
    return value

def _span(location):
    physical = _object(_object(location, ('physicalLocation',))['physicalLocation'], ('artifactLocation', 'region'))
    path = _path(_object(physical['artifactLocation'], ('uri',))['uri'])
    region = _object(physical['region'], ('startLine',), ('startColumn','endLine','endColumn'))
    start_line = _integer(region['startLine'], 1)
    start_column = _integer(region.get('startColumn', 1), 1)
    end_line = _integer(region.get('endLine', start_line), 1)
    end_column = _integer(region.get('endColumn', start_column), 1)
    if (end_line, end_column) < (start_line, start_column):
        raise ValueError('Reversed span')
    return ImportedSpan(path, start_line, start_column, end_line, end_column)

def import_sarif(payload: bytes, expected_revision: str, limits: RecordLimits) -> tuple[ImportedObservation, ...]:
    """Accept an inert subset only; active/unknown fields fail closed, no I/O."""
    _revision(expected_revision)
    limits = RecordLimits(min(limits.max_depth,64), min(limits.max_aggregate_items,100_000),
                          limits.max_string_bytes, min(limits.max_payload_bytes,8_388_608))
    root = _object(_decode(payload, limits), ('version','runs'))
    if root['version'] != '2.1.0': raise ValueError('SARIF 2.1.0 required')
    observations = set()
    for run in _list(root['runs']):
        _object(run, ('tool','properties','results'))
        revision = _revision(_object(run['properties'], ('pullraptorRevision',))['pullraptorRevision'])
        if revision != expected_revision: raise ValueError('Wrong review revision')
        driver = _object(_object(run['tool'], ('driver',))['driver'], ('name','version'))
        producer, version = _text(driver['name']), _text(driver['version'])
        for result in _list(run['results']):
            _object(result, ('ruleId','message','locations'))
            claim = _text(_object(result['message'], ('text',))['text'])
            rule = _text(result['ruleId'])
            locations = _list(result['locations'])
            if len(locations) != 1: raise ValueError('Exactly one physical location required')
            observations.add(ImportedObservation(producer, version, revision, claim, _span(locations[0]), 'external', rule))
    return tuple(sorted(observations, key=lambda o: (o.producer,o.version,o.revision,o.rule,o.span,o.claim)))
