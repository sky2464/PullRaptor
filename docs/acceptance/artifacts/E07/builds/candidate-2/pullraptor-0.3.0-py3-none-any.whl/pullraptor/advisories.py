"""Owned exact-inventory/advisory schemas. No installation, fetching or cache."""
from dataclasses import dataclass
import re
from pullraptor.models import RecordLimits
from pullraptor.scanner_import import ImportedObservation, _decode, _object, _text, _revision, _list, _integer

@dataclass(frozen=True, order=True)
class LockedPackage:
    name: str
    version: str

@dataclass(frozen=True)
class LockfileInventory:
    ecosystem: str
    schema_version: str
    packages: tuple[LockedPackage, ...]
    revision: str

@dataclass(frozen=True, order=True)
class AdvisoryEntry:
    id: str
    ecosystem: str
    name: str
    version: str

@dataclass(frozen=True)
class AdvisorySnapshot:
    origin: str
    retrieved_at: int
    valid_until: int
    schema_version: str
    entries: tuple[AdvisoryEntry, ...]
    checked_at: int

def _ecosystem(value):
    if value not in ('python','npm'): raise ValueError('Unsupported ecosystem')
    return value

def _name(value, ecosystem):
    value = _text(value)
    pattern = r'[A-Za-z0-9]+(?:[._-][A-Za-z0-9]+)*' if ecosystem == 'python' else r'(?:@[a-z0-9._-]+/)?[a-z0-9][a-z0-9._-]*'
    if not re.fullmatch(pattern, value): raise ValueError('Unsupported package name')
    return re.sub(r'[-_.]+','-',value).lower() if ecosystem == 'python' else value

def _version(value, ecosystem):
    value = _text(value)
    # Deliberately narrow owned exact version subset; never interpret ranges.
    pattern = r'(?:0|[1-9][0-9]*)(?:\.(?:0|[1-9][0-9]*)){1,3}' if ecosystem == 'python' else r'(?:0|[1-9][0-9]*)\.(?:0|[1-9][0-9]*)\.(?:0|[1-9][0-9]*)(?:-[A-Za-z0-9]+(?:[.-][A-Za-z0-9]+)*)?'
    if not re.fullmatch(pattern, value): raise ValueError('Unsupported exact version; coverage gap')
    return value

def parse_lockfile(payload: bytes, revision: str, *, limits: RecordLimits = RecordLimits()) -> LockfileInventory:
    _revision(revision)
    root = _decode(payload, limits)
    packages = set()
    if root.get('schema') == 'python-lock/1':
        _object(root, ('schema','packages'))
        ecosystem, schema = 'python', 'python-lock/1'
        for package in _list(root['packages']):
            _object(package, ('name','version'))
            packages.add(LockedPackage(_name(package['name'],ecosystem),_version(package['version'],ecosystem)))
        if len({p.name for p in packages}) != len(packages):
            raise ValueError('Ambiguous normalized Python package identity')
    else:
        _object(root, ('lockfileVersion','packages'), ('name','version','requires'))
        if type(root['lockfileVersion']) is not int or root['lockfileVersion'] != 3: raise ValueError('package-lock schema 3 required')
        ecosystem, schema = 'npm', 'package-lock/3'
        if not isinstance(root['packages'], dict): raise ValueError('packages mapping required')
        for path, package in root['packages'].items():
            if path == '':
                _object(package, (), ('name','version','license','dependencies','devDependencies','optionalDependencies','engines'))
                continue
            if not isinstance(path,str) or not path.startswith('node_modules/') or '\\' in path or any(p in ('','..','.') for p in path.split('/')):
                raise ValueError('Unsupported package path')
            _object(package, ('version',), ('name','resolved','integrity','dev','optional','devOptional','license','dependencies','optionalDependencies','peerDependencies','peerDependenciesMeta','engines','bin','hasInstallScript','funding','os','cpu'))
            name = path.rsplit('node_modules/',1)[1]
            if 'name' in package and package['name'] != name: raise ValueError('Alias package unsupported')
            packages.add(LockedPackage(_name(name,ecosystem),_version(package['version'],ecosystem)))
    return LockfileInventory(ecosystem, schema, tuple(sorted(packages)), revision)

def parse_advisory_snapshot(payload: bytes, *, now: int, limits: RecordLimits = RecordLimits()) -> AdvisorySnapshot:
    limits = RecordLimits(min(limits.max_depth,64),min(limits.max_aggregate_items,100_000),limits.max_string_bytes,min(limits.max_payload_bytes,1_048_576))
    root = _object(_decode(payload,limits), ('schema','origin','retrieved_at','valid_until','entries'))
    if root['schema'] != 'advisory-snapshot/1': raise ValueError('Unsupported advisory schema')
    origin = _text(root['origin'])
    if not origin.startswith('offline:') or not re.fullmatch(r'offline:[A-Za-z0-9._-]+',origin): raise ValueError('Only offline origin admitted')
    retrieved, until = _integer(root['retrieved_at']), _integer(root['valid_until'])
    now = _integer(now)
    if until <= retrieved: raise ValueError('Invalid freshness interval')
    entries = set()
    for entry in _list(root['entries']):
        _object(entry, ('id','ecosystem','name','version'))
        ecosystem = _ecosystem(entry['ecosystem'])
        entries.add(AdvisoryEntry(_text(entry['id']),ecosystem,_name(entry['name'],ecosystem),_version(entry['version'],ecosystem)))
    return AdvisorySnapshot(origin,retrieved,until,root['schema'],tuple(sorted(entries)),now)

def match_advisories(lockfile: LockfileInventory, response: AdvisorySnapshot) -> tuple[ImportedObservation, ...]:
    """Exact matching is a claimed affected version, never reachable exploitation."""
    _revision(lockfile.revision)
    ecosystem = _ecosystem(lockfile.ecosystem)
    if lockfile.schema_version != {'python':'python-lock/1','npm':'package-lock/3'}[ecosystem] or response.schema_version != 'advisory-snapshot/1':
        raise ValueError('Unsupported schema')
    _integer(response.checked_at); _integer(response.retrieved_at); _integer(response.valid_until)
    if response.valid_until <= response.retrieved_at: raise ValueError('Invalid freshness interval')
    if not re.fullmatch(r'offline:[A-Za-z0-9._-]+',response.origin): raise ValueError('Only offline origin admitted')
    packages = {(_name(p.name,ecosystem),_version(p.version,ecosystem)) for p in lockfile.packages}
    trust = 'external' if response.retrieved_at <= response.checked_at < response.valid_until else 'stale'
    observations = set()
    for entry in response.entries:
        entry_ecosystem = _ecosystem(entry.ecosystem)
        name, version = _name(entry.name,entry_ecosystem), _version(entry.version,entry_ecosystem)
        if entry_ecosystem != ecosystem or (name,version) not in packages: continue
        claim = f'External advisory {_text(entry.id)} claims {ecosystem} package {name} {version} is affected; reachability and exploitability unknown'
        if trust == 'stale': claim = 'Freshness unknown; ' + claim
        observations.add(ImportedObservation(response.origin,response.schema_version,lockfile.revision,claim,None,trust,entry.id,response.origin,ecosystem))
    return tuple(sorted(observations,key=lambda o:(o.rule,o.claim)))
