"""Bounded inert relationship presentation, never a correctness/authority input."""
from dataclasses import dataclass
import html
import re


@dataclass(frozen=True)
class GraphNode:
    id: str
    label: str


@dataclass(frozen=True)
class GraphEdge:
    source_id: str
    target_id: str
    relation: str
    certainty: str


def _label(value: str) -> str:
    # Keep source-supplied diagram syntax, URI schemes and controls out entirely.
    text = ''.join(c for c in value[:256] if c.isalnum() or c in ' _./-')
    return html.escape(text, quote=True) or 'unnamed'


def render_graph(nodes: tuple[GraphNode, ...], edges: tuple[GraphEdge, ...]) -> str:
    if len(nodes) > 256 or len(edges) > 1024:
        raise ValueError('graph presentation bound exceeded')
    ordered = sorted(nodes, key=lambda n: n.id)
    ids = {node.id: f'n{i}' for i, node in enumerate(ordered)}
    if len(ids) != len(ordered):
        raise ValueError('duplicate graph node')
    if any(e.source_id not in ids or e.target_id not in ids for e in edges):
        raise ValueError('foreign graph edge')
    relations = {'imports', 'calls', 'depends_on', 'presentation'}
    if any(e.relation not in relations or e.certainty not in {'supported','unknown','conflicting','stale'} for e in edges):
        raise ValueError('unsupported relation or certainty')
    adjacency = {n.id: [] for n in ordered}
    indegree = {n.id: 0 for n in ordered}
    for e in edges:
        adjacency[e.source_id].append(e.target_id)
        indegree[e.target_id] += 1
    ready = sorted(k for k,v in indegree.items() if not v)
    seen = 0
    while ready:
        item = ready.pop(0)
        seen += 1
        for target in adjacency[item]:
            indegree[target] -= 1
            if not indegree[target]:
                ready.append(target)
                ready.sort()
    if seen != len(nodes) or any(e.certainty != 'supported' for e in edges):
        lines = ['File walkthrough (cycles or uncertain relationships; impact remains unknown):']
        lines.extend(f'- {ids[n.id]}: {_label(n.label)}' for n in ordered)
        lines.extend(f'- {ids[e.source_id]} to {ids[e.target_id]}: {e.relation} ({e.certainty})' for e in sorted(edges, key=lambda e:(e.source_id,e.target_id,e.relation,e.certainty)))
        return '\n'.join(lines)
    lines = ['flowchart TD']
    lines.extend(f'  {ids[n.id]}["{_label(n.label)}"]' for n in ordered)
    lines.extend(f'  {ids[e.source_id]} -->|{e.relation}: {e.certainty}| {ids[e.target_id]}' for e in sorted(edges,key=lambda e:(e.source_id,e.target_id,e.relation,e.certainty)))
    return '\n'.join(lines)
